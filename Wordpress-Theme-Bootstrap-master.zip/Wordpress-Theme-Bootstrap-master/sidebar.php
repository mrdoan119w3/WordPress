<aside id="sidebar" class="sidebar" role="complementary" itemscope itemtype="http://schema.org/WPSideBar">

</aside>