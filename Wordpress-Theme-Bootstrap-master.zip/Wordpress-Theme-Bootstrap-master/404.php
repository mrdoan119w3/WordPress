<?php get_header();?>
<div class="container">
	<div class="row">
		<div class="col-xs-12 text-center" style="padding: 30px 0; color: red;">
			<h1>Oh No! That Page Doesn't Exist!</h1>
		</div>
	</div>
</div>
<?php get_footer();?>