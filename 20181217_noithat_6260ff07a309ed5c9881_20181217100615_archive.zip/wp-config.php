<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'noi_that');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '8;HS/0)}1-,CKmsxpq{kS=(qn7D:1;$3]{X!3>Zc7hf[/,(~cfABP}G]8?Gj#Y#f');
define('SECURE_AUTH_KEY',  'sYq,D6qbpA$:(,eBo?`e)eI%2[h[FiqvzIHr^AM4C c5mR`G{a6{Iky`=}u*6p`6');
define('LOGGED_IN_KEY',    'WvU=MU3N#2.a/$gip^Q Q&a/K>)^_5T{?=c< Rq-xGmtv9Z5Z_h9[T:g~z_7GB4X');
define('NONCE_KEY',        'AVwA%!aOd$Gmj T3+j@DVkcu{RCOp)}j97lXKZl=YfA3IsT.Doqi}yHy.d{jD6$~');
define('AUTH_SALT',        'bKRKV;FY^PJ,zn41F/qDnW>Z<]Rx&kFcZh:,Qc_|k=t@HoH9HBY^E&`{qDyL7LwY');
define('SECURE_AUTH_SALT', 'u+I-&$js@[#(S?_ir)W>e%(-IU1`I(8`Aa`+3<L!#iy!*UD-rAt`{d=.]#s %Cl0');
define('LOGGED_IN_SALT',   ']J |enP{h{~j8SOU#jPW$&H86P&WK/Ku#gVazCzQXUx:YSAt`?A24I~]{h%`w[H%');
define('NONCE_SALT',       'n|$lmt~(fD( d2GsFS}Pcb/=d.tS09Wz|im+}Yo5a<?-[lp3W1h@-6d>&M)H]{>x');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
